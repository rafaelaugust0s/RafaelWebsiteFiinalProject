/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.*;
import com.mysql.jdbc.Driver;
/**
 *
 * @author rafaelsuarez
 */
public class users {
    
    
    
     public String register_user(String user[]){
        
        
        
        String name= user [0];
        String email= user [1];
        String password= user [2];
        
        try{

        
        
        Class.forName("com.mysql.jdbc.Driver");
        
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp102","root","R@faelaugustos");
        
       
                
        String query = "insert into users (name,email,password) values (?,?,?)" ;
        
        PreparedStatement ps = conn.prepareStatement(query);
        
        ps.setString(1,name);
        ps.setString(2,email);
        ps.setString(3,password);
        
        int result = ps.executeUpdate();
        
            if (result == 0){
            
           // return true;
                }else{
               // return false;
                }
        //return result.toString();
                  return " ";
        
        }

    catch (Exception e){
         return e.toString();
    }
        
//        System.out.print("Something went wrong!!");
//    }
           

    }         
       
     
     
            public String[] login_users (String user[]){
                
                
                
            String email= user [0];
            String password= user [1];
        
        String[] response = new String[3];
        
        try{

       
        Class.forName("com.mysql.jdbc.Driver");
        
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp102","root","R@faelaugustos");
        
       
                
        String query = "select * from users where email= '"+email+"' and password='"+password+"';";
        response[0]= query;
        
            Statement stmt = conn.createStatement();
        
                ResultSet rs=stmt.executeQuery(query);
        
             String name= " ";
        
        while (rs.next()){
            
            
            response[0] =rs.getString("name");
            response[1] =rs.getString("id");
            response[2] =rs.getString("email");

            
        }
     

           return response;
        
        }catch (Exception e){
        
         response[0]= "ERROR -Something went wrong!!";
         
          return response;
        }
        

            

    
        }  
            
      public String membership_users (String user[]){
          
            String name= user [0];
            String address= user [1];
            
            
//            String[] result = new String[3];
            
                    try{

       
        Class.forName("com.mysql.jdbc.Driver");
        
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp102","root","R@faelaugustos");
        
        String query = "INSERT INTO membership (name,address) VALUES (?,?)";
        
        PreparedStatement ps = conn.prepareStatement(query);
        
        ps.setString(1,name);
        ps.setString(2,address);
        
        
        int result = ps.executeUpdate();
        
            if (result == 0){
            
           // return true;
                }else{
               // return false;
                }
        //return result.toString();
                  return " ";
        
        }

    catch (Exception e){
         return e.toString();
    }
                    
      }               
              public String update (String user[]){
          
            String name= user [0];
            String address= user [1];
            String id= user [2];
            
//            String[] result = new String[3];
            
                    try{

       
        Class.forName("com.mysql.jdbc.Driver");
        
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jsp102","root","R@faelaugustos");
        
        String query = "SELECT * FROM membership WHERE (id) VALUES (?)";
                
//                "UPDATE membership SET name=?, address=?, WHERE id=? VALUES (?,)";
        
        
        PreparedStatement ps = conn.prepareStatement(query);
        
        ps.setString(1,name);
        ps.setString(2,address);
        ps.setString(3,id);
        
        
        
        int result = ps.executeUpdate();
        
            if (result == 0){
            
           // return true;
                }else{
               // return false;
                }
        //return result.toString();
                  return " ";
        
        }

    catch (Exception e){
         return e.toString();
    }
                        
                    
      }
        
//                String sql = "INSERT INTO membership (name,adress) VALUES (?, ?)";
// 
//PreparedStatement statement = conn.prepareStatement(sql);
//statement.setString(1, " ");
//statement.setString(2, " ");
//
// 
//int rowsInserted = statement.executeUpdate();
//if (rowsInserted > 0) {
//    System.out.println("A new user was inserted successfully!");
//}
//        
//        
        
        
        
                
//        String query = "select * from membership where name= '"+name+"' and address='"+address+"';";
//                  
//        String query = "insert into membership (name,adress) values (?,?)" ;
//        
//        PreparedStatement ps = conn.prepareStatement(query);
//        response[0]= query;
//        
//            Statement stmt = conn.createStatement();
//        
//                ResultSet rs=stmt.executeQuery(query);
//                
//        
//             String names= " ";
//        
//        while (rs.next()){
//            
//            
//            response[0] =rs.getString("name");
//            response[1] =rs.getString("address");
//            
//
//            
//        }
//     
//
//           return response;
//        
//        }catch (Exception e){
//        
//         response[0]= "ERROR -Something went wrong!!";
//         
//          return response;
//         
//      } 
//                    
//      }
      
}




