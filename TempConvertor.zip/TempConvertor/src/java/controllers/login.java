/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import Models.users;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;


/**
 *
 * @author rafaelsuarez
 */
public class login extends HttpServlet {
    
    
    
    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
          
        
      

       }
    
     
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        
        
          String[] login_info = {request.getParameter("email"),request.getParameter("password")};
                
                
                users user= new users();
                
                String result[] = user.login_users (login_info);
                
                          PrintWriter pw = response.getWriter();
                          
                          pw.println(result[0]);
                          if (result[0] == null){
                              
                              request.setAttribute("Error","Invalid username or password. Please Try again");
                              
                              RequestDispatcher dispatcher= request.getRequestDispatcher("login.jsp");
                              dispatcher.forward(request, response);
                              
                          }else{  
                              
                         
//                             request.setAttribute("user_name", result[0]);
//                               request.setAttribute("user_id", result[1]);
                               
                               
                               Cookie user_name = new Cookie("user_name",result[0]);
                               Cookie user_id = new Cookie("user_id",result[1]);
                               Cookie user_email = new Cookie("user_email",result[2]);

                               
                               response.addCookie(user_name);
                               response.addCookie(user_id);
                               response.addCookie(user_email);

                               
                              RequestDispatcher dispatcher= request.getRequestDispatcher("convertor.jsp");
                              dispatcher.forward(request, response);
                          }
                    
                       pw.println(result);
                       
                       
                
                
        
    }


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
